﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using UsingLINQtoEntity.Database;
using UsingLINQtoEntity.Models;

namespace UsingLINQtoEntity
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
